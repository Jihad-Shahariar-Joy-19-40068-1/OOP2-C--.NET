﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory_Management_System_I_.Entities
{
    class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
